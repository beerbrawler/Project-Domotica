# Slagboom master

Library die basis vormt voor de interactie tussen de app en de Arduino.

pls no copy