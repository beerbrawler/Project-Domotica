# Slagboom slave

Voor de Arduino's in de keten.