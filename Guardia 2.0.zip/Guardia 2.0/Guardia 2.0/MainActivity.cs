﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;
using System.Timers;
using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Widget;
using Environment = System.Environment;

namespace Guardia_2._0
{
    [Activity(Label = "Guardia", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        public static int LogsSaved { get; set; } = 15;

        public List<string> Logs { get; set; } = new List<string>();

        public Button Connect { get; set; }

        public Timer TimerSockets { get; set; }

        public Socket Socket { get; set; }

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            CameraButton();

            UpdateLog();

            ConnectButton();
        }

        public void CameraButton()
        {
            Button cameraButton = FindViewById<Button>(Resource.Id.CAMERA);
            cameraButton.Click += delegate { StartActivity(typeof(CameraActivity)); };
        }

        public void UpdateLog()
        {
            Button updateLog = FindViewById<Button>(Resource.Id.UPDATE_LOG);
            TextView log = FindViewById<TextView>(Resource.Id.LOG);
            updateLog.Click += delegate
            {
                //Logs.Add(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                string answer = ExecuteCommand("q");
//                if (answer != "error" && answer.Length > 0 && answer != "")
//                {
//                    int answerInt = Convert.ToInt32(answer);
//                    answer = answerInt.ToString("00:00");
//                }
                Logs.Add(answer);
                DisplayLog(Logs, log);
                NotifyUser(Logs[Logs.Count - 1]);
            };
        }

        public void ConnectButton()
        {
            Connect = FindViewById<Button>(Resource.Id.buttonConnect);
            EditText ipAddress = FindViewById<EditText>(Resource.Id.editTextIPAddress);
            EditText port = FindViewById<EditText>(Resource.Id.editTextIPPort);

            Connect.Click += delegate
            {
                if (ValidIpAddress(ipAddress.Text) && ValidPort(port.Text))
                    ConnectSocket(ipAddress.Text, port.Text);
            };
        }

        public void DisplayLog(List<string> logs, TextView log)
        {
            log.Text = Environment.NewLine;
            for (int i = Math.Max(logs.Count - LogsSaved, 0); i < logs.Count; i++)
                log.Text += logs[i] + Environment.NewLine;
        }

        public void NotifyUser(string message)
        {
            Intent intent = new Intent(this, typeof(MainActivity));

            PendingIntent pendingIntent = PendingIntent.GetActivity(this, 0, intent, PendingIntentFlags.OneShot);

            Notification notification = new Notification.Builder(this)
                .SetContentIntent(pendingIntent)
                .SetContentTitle("Guardia")
                .SetContentText(message)
                .SetSmallIcon(Resource.Drawable.Icon)
                .SetPriority((int) NotificationPriority.Max)
                .SetDefaults(NotificationDefaults.Sound)
                .SetAutoCancel(true)
                .Build();
            NotificationManager notificationManager = GetSystemService(NotificationService) as NotificationManager;
            notificationManager?.Notify(420, notification);
        }

        public bool ValidIpAddress(string ip)
        {
            if (ip == "") return false;
            Regex regex = new Regex("\\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\\.|$)){4}\\b");
            Match match = regex.Match(ip);
            return match.Success;
        }

        public bool ValidPort(string port)
        {
            if (port != "")
            {
                Regex regex = new Regex("[0-9]+");

                if (regex.Match(port).Success)
                {
                    int portAsInteger = int.Parse(port);
                    return portAsInteger >= 0 && portAsInteger <= 65535;
                }
                return false;
            }
            return false;
        }

        public void ConnectSocket(string ip, string port)
        {
            RunOnUiThread(() =>
            {
                if (Socket == null)
                {
                    UpdateConnectionState(1, "Connecting...");
                    try
                    {
                        Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        Socket.Connect(new IPEndPoint(IPAddress.Parse(ip), Convert.ToInt32(port)));
                        if (Socket.Connected)
                            UpdateConnectionState(2, "Connected");
                    }
                    catch (Exception exception)
                    {
                        //TimerSockets.Enabled = false;
                        if (Socket != null)
                        {
                            Socket.Close();
                            Socket = null;
                        }
                        UpdateConnectionState(4, exception.Message);
                    }
                }
                else
                {
                    Socket.Close();
                    Socket = null;
                    //TimerSockets.Enabled = false;
                    UpdateConnectionState(4, "Disconnected");
                }
            });
        }

        public void UpdateConnectionState(int state, string text)
        {
            TextView status = FindViewById<TextView>(Resource.Id.textViewServerConnect);

            string connectText = "Connect";
            bool connectEnabled = true;
            Color color = Color.Red;

            if (state == 1)
            {
                connectText = "Please wait";
                color = Color.Orange;
                connectEnabled = false;
            }
            else if (state == 2)
            {
                connectText = "Disconnect";
                color = Color.Green;
            }
            RunOnUiThread(() =>
            {
                status.Text = text;
                if (connectText != null)
                {
                    Connect.Text = connectText;
                    status.SetTextColor(color);
                    Connect.Enabled = connectEnabled;
                }
            });
        }

        public string ExecuteCommand(string cmd)
        {
            byte[] buffer = new byte[4];
            string result = "";
            int i = 0;
            if (Socket != null)
            {
                Socket.Send(Encoding.ASCII.GetBytes(cmd));

                try
                {
                    int bytesRead = Socket.Receive(buffer);
                    while (Socket.Available > 0)
                    {
                        bytesRead = Socket.Receive(buffer);
                        Console.Write("");
                    }
                    result = bytesRead == 4 ? Encoding.ASCII.GetString(buffer, 0, bytesRead) : "error";
                    Console.Write("");
                }
                catch (Exception exception)
                {
                    result = exception.ToString();
                    if (Socket != null)
                    {
                        Socket.Close();
                        Socket = null;
                    }
                    UpdateConnectionState(3, result);
                }
            }
            return result;
        }
    }
}