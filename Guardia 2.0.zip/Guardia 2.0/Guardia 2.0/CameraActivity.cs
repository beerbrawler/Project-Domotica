

using Android.App;
using Android.OS;
using Android.Webkit;

namespace Guardia_2._0
{
    [Activity(Label = "Camera")]
    public class CameraActivity : Activity
    {
        public string Url = "http://admin:123456789abc@192.168.1.20/Streaming/channels/2/preview";
        public WebView web;
        
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Camera);
            web = FindViewById<WebView>(Resource.Id.webView);
            web.LoadUrl(Url);
            web.Settings.LoadWithOverviewMode = true;
            web.Settings.UseWideViewPort = true;
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            web.Destroy();
        }
    }
}